library("testthat")
library("datasets")
library("rio.db")
test_check("rio.db", reporter = "summary")
