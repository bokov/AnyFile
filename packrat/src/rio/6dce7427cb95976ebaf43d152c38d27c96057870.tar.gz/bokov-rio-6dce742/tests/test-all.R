library("testthat")
library("rio")
test_check("rio", reporter = "summary")
